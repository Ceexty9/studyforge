export interface User {
  id: string;
  username: string;
  createdAt: string;
  totalStudyTime: number;
  currentStreak: number;
  longestStreak: number;
  totalQuestionsAnswered: number;
  correctAnswers: number;
  achievements: Achievement[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  progress: number;
  target: number;
}

export interface Subject {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  topics: Topic[];
  totalVideos: number;
  totalQuestions: number;
  completedVideos: number;
  correctAnswers: number;
}

export interface Topic {
  id: string;
  subjectId: string;
  name: string;
  description: string;
  videos: Video[];
  questions: Question[];
  progress: number;
  completed: boolean;
}

export interface Video {
  id: string;
  topicId: string;
  title: string;
  description: string;
  duration: number;
  thumbnailUrl: string;
  videoUrl: string;
  downloadStatus: 'not_downloaded' | 'downloading' | 'downloaded' | 'error';
  downloadProgress: number;
  watchProgress: number;
  completed: boolean;
  lastWatched?: string;
}

export interface Question {
  id: string;
  topicId: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  type: 'multiple_choice' | 'true_false';
  answered: boolean;
  userAnswer?: number;
  correct?: boolean;
  answeredAt?: string;
}

export interface StudySession {
  id: string;
  subjectId: string;
  topicId?: string;
  type: 'video' | 'practice';
  startTime: string;
  endTime?: string;
  duration: number;
  questionsAnswered?: number;
  correctAnswers?: number;
  videosWatched?: number;
}

export interface DownloadTask {
  id: string;
  videoId: string;
  progress: number;
  status: 'pending' | 'downloading' | 'completed' | 'error';
}