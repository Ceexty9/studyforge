import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import { useEffect, useState, useCallback, useMemo } from 'react';
import { SUBJECTS } from '@/constants/subjects';
import { SAMPLE_QUESTIONS } from '@/constants/questions';
import { User, Subject, Question, StudySession, Achievement } from '@/types/study';

const STORAGE_KEYS = {
  USER: 'study_app_user',
  SUBJECTS: 'study_app_subjects',
  QUESTIONS: 'study_app_questions',
  SESSIONS: 'study_app_sessions',
};

const DEFAULT_USER: User = {
  id: 'user_1',
  username: '',
  createdAt: new Date().toISOString(),
  totalStudyTime: 0,
  currentStreak: 0,
  longestStreak: 0,
  totalQuestionsAnswered: 0,
  correctAnswers: 0,
  achievements: [],
};

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_question',
    title: 'First Steps',
    description: 'Answer your first question',
    icon: 'play',
    progress: 0,
    target: 1,
  },
  {
    id: 'ten_questions',
    title: 'Getting Started',
    description: 'Answer 10 questions correctly',
    icon: 'target',
    progress: 0,
    target: 10,
  },
  {
    id: 'hundred_questions',
    title: 'Dedicated Learner',
    description: 'Answer 100 questions correctly',
    icon: 'award',
    progress: 0,
    target: 100,
  },
  {
    id: 'seven_day_streak',
    title: 'Week Warrior',
    description: 'Study for 7 days in a row',
    icon: 'flame',
    progress: 0,
    target: 7,
  },
  {
    id: 'perfect_score',
    title: 'Perfectionist',
    description: 'Get 100% on a practice session',
    icon: 'star',
    progress: 0,
    target: 1,
  },
];

export const [StudyProvider, useStudy] = createContextHook(() => {
  const [user, setUser] = useState<User>(DEFAULT_USER);
  const [subjects, setSubjects] = useState<Subject[]>(SUBJECTS);
  const [questions, setQuestions] = useState<Question[]>(SAMPLE_QUESTIONS);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentSession, setCurrentSession] = useState<StudySession | null>(null);

  // Load data from storage
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userData, subjectsData, questionsData, sessionsData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.USER),
        AsyncStorage.getItem(STORAGE_KEYS.SUBJECTS),
        AsyncStorage.getItem(STORAGE_KEYS.QUESTIONS),
        AsyncStorage.getItem(STORAGE_KEYS.SESSIONS),
      ]);

      if (userData) {
        const parsedUser = JSON.parse(userData);
        setUser({ ...parsedUser, achievements: parsedUser.achievements || DEFAULT_ACHIEVEMENTS });
      } else {
        setUser({ ...DEFAULT_USER, achievements: DEFAULT_ACHIEVEMENTS });
      }

      if (subjectsData) {
        setSubjects(JSON.parse(subjectsData));
      }

      if (questionsData) {
        setQuestions(JSON.parse(questionsData));
      } else {
        // Initialize with sample questions
        setQuestions(SAMPLE_QUESTIONS);
        await AsyncStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(SAMPLE_QUESTIONS));
      }

      if (sessionsData) {
        setSessions(JSON.parse(sessionsData));
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveUser = async (userData: User) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(userData));
      setUser(userData);
    } catch (error) {
      console.error('Error saving user:', error);
    }
  };



  const saveQuestions = async (questionsData: Question[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questionsData));
      setQuestions(questionsData);
    } catch (error) {
      console.error('Error saving questions:', error);
    }
  };

  const saveSessions = async (sessionsData: StudySession[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessionsData));
      setSessions(sessionsData);
    } catch (error) {
      console.error('Error saving sessions:', error);
    }
  };

  const updateUsername = useCallback(async (username: string) => {
    const updatedUser = { ...user, username };
    await saveUser(updatedUser);
  }, [user]);

  const answerQuestion = useCallback(async (questionId: string, userAnswer: number) => {
    const updatedQuestions = questions.map(q => {
      if (q.id === questionId) {
        const correct = userAnswer === q.correctAnswer;
        return {
          ...q,
          answered: true,
          userAnswer,
          correct,
          answeredAt: new Date().toISOString(),
        };
      }
      return q;
    });

    const question = questions.find(q => q.id === questionId);
    if (question) {
      const correct = userAnswer === question.correctAnswer;
      const updatedUser = {
        ...user,
        totalQuestionsAnswered: user.totalQuestionsAnswered + 1,
        correctAnswers: correct ? user.correctAnswers + 1 : user.correctAnswers,
      };

      // Check for achievements
      const updatedAchievements = checkAchievements(updatedUser);
      updatedUser.achievements = updatedAchievements;

      await Promise.all([
        saveQuestions(updatedQuestions),
        saveUser(updatedUser),
      ]);
    }
  }, [questions, user]);

  const checkAchievements = (userData: User): Achievement[] => {
    return userData.achievements.map(achievement => {
      let progress = achievement.progress;
      let unlockedAt = achievement.unlockedAt;

      switch (achievement.id) {
        case 'first_question':
          progress = Math.min(userData.totalQuestionsAnswered, 1);
          break;
        case 'ten_questions':
          progress = Math.min(userData.correctAnswers, 10);
          break;
        case 'hundred_questions':
          progress = Math.min(userData.correctAnswers, 100);
          break;
        case 'seven_day_streak':
          progress = Math.min(userData.currentStreak, 7);
          break;
      }

      if (progress >= achievement.target && !unlockedAt) {
        unlockedAt = new Date().toISOString();
      }

      return { ...achievement, progress, unlockedAt };
    });
  };

  const startSession = useCallback((subjectId: string, type: 'video' | 'practice', topicId?: string) => {
    const session: StudySession = {
      id: `session_${Date.now()}`,
      subjectId,
      topicId,
      type,
      startTime: new Date().toISOString(),
      duration: 0,
      questionsAnswered: 0,
      correctAnswers: 0,
      videosWatched: 0,
    };
    setCurrentSession(session);
  }, []);

  const endSession = useCallback(async () => {
    if (!currentSession) return;

    const endTime = new Date().toISOString();
    const duration = new Date(endTime).getTime() - new Date(currentSession.startTime).getTime();

    const completedSession: StudySession = {
      ...currentSession,
      endTime,
      duration,
    };

    const updatedSessions = [...sessions, completedSession];
    const updatedUser = {
      ...user,
      totalStudyTime: user.totalStudyTime + duration,
    };

    await Promise.all([
      saveSessions(updatedSessions),
      saveUser(updatedUser),
    ]);

    setCurrentSession(null);
  }, [currentSession, sessions, user]);

  const getSubjectProgress = useCallback((subjectId: string) => {
    const subjectQuestions = questions.filter(q => {
      const topic = subjects.find(s => s.id === subjectId)?.topics.find(t => t.id === q.topicId);
      return topic?.subjectId === subjectId;
    });

    const answeredQuestions = subjectQuestions.filter(q => q.answered);
    const correctAnswers = subjectQuestions.filter(q => q.correct);

    return {
      totalQuestions: subjectQuestions.length,
      answeredQuestions: answeredQuestions.length,
      correctAnswers: correctAnswers.length,
      progress: subjectQuestions.length > 0 ? (answeredQuestions.length / subjectQuestions.length) * 100 : 0,
    };
  }, [questions, subjects]);

  const getTopicQuestions = useCallback((topicId: string) => {
    return questions.filter(q => q.topicId === topicId);
  }, [questions]);

  const resetProgress = useCallback(async () => {
    const resetQuestions = questions.map(q => ({
      ...q,
      answered: false,
      userAnswer: undefined,
      correct: undefined,
      answeredAt: undefined,
    }));

    const resetUser = {
      ...DEFAULT_USER,
      username: user.username,
      achievements: DEFAULT_ACHIEVEMENTS,
    };

    await Promise.all([
      saveQuestions(resetQuestions),
      saveUser(resetUser),
      saveSessions([]),
    ]);
  }, [questions, user.username]);

  return useMemo(() => ({
    user,
    subjects,
    questions,
    sessions,
    currentSession,
    isLoading,
    updateUsername,
    answerQuestion,
    startSession,
    endSession,
    getSubjectProgress,
    getTopicQuestions,
    resetProgress,
  }), [
    user,
    subjects,
    questions,
    sessions,
    currentSession,
    isLoading,
    updateUsername,
    answerQuestion,
    startSession,
    endSession,
    getSubjectProgress,
    getTopicQuestions,
    resetProgress,
  ]);
});