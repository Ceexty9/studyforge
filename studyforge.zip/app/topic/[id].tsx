import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, RotateCcw, CheckCircle, Target } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';
import QuestionCard from '@/components/QuestionCard';
import ProgressRing from '@/components/ProgressRing';

export default function TopicPracticeScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { subjects, getTopicQuestions, answerQuestion, startSession, endSession } = useStudy();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [sessionStarted, setSessionStarted] = useState(false);

  const topicQuestions = getTopicQuestions(id as string);
  const topic = subjects.flatMap(s => s.topics).find(t => t.id === id);
  const subject = subjects.find(s => s.topics.some(t => t.id === id));

  useEffect(() => {
    if (topicQuestions.length > 0 && !sessionStarted && subject) {
      startSession(subject.id, 'practice', id as string);
      setSessionStarted(true);
    }
  }, [topicQuestions, sessionStarted, subject, startSession, id]);

  if (!topic || !subject) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Topic not found</Text>
      </View>
    );
  }

  const handleAnswer = async (questionId: string, answer: number) => {
    await answerQuestion(questionId, answer);
    
    // Move to next question after a delay
    setTimeout(() => {
      if (currentQuestionIndex < topicQuestions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        // Session complete
        handleSessionComplete();
      }
    }, 2000);
  };

  const handleSessionComplete = async () => {
    await endSession();
    
    const answeredQuestions = topicQuestions.filter(q => q.answered);
    const correctAnswers = answeredQuestions.filter(q => q.correct);
    const score = answeredQuestions.length > 0 
      ? Math.round((correctAnswers.length / answeredQuestions.length) * 100) 
      : 0;

    Alert.alert(
      'Topic Complete!',
      `You scored ${score}% on ${topic.name} (${correctAnswers.length}/${answeredQuestions.length} correct)`,
      [
        { text: 'Review Answers', onPress: () => setCurrentQuestionIndex(0) },
        { text: 'Back to Subject', onPress: () => router.push(`/subject/${subject.id}`) },
      ]
    );
  };

  const handleRestart = () => {
    Alert.alert(
      'Restart Topic',
      'Are you sure you want to restart this topic practice?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Restart', 
          onPress: () => {
            setCurrentQuestionIndex(0);
            setSessionStarted(false);
          }
        },
      ]
    );
  };

  if (topicQuestions.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No questions available for this topic yet.</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const currentQuestion = topicQuestions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / topicQuestions.length) * 100;
  const answeredQuestions = topicQuestions.filter(q => q.answered);
  const correctAnswers = answeredQuestions.filter(q => q.correct);
  const topicProgress = topicQuestions.length > 0 
    ? (answeredQuestions.length / topicQuestions.length) * 100 
    : 0;

  return (
    <View style={styles.container}>
      <View style={[styles.topicHeader, { backgroundColor: subject.color + '10' }]}>
        <View style={styles.topicInfo}>
          <View style={[styles.topicIcon, { backgroundColor: subject.color + '20' }]}>
            <Target size={24} color={subject.color} />
          </View>
          
          <View style={styles.topicDetails}>
            <Text style={styles.topicName}>{topic.name}</Text>
            <Text style={styles.subjectName}>{subject.name}</Text>
          </View>
          
          <ProgressRing
            progress={topicProgress}
            size={60}
            strokeWidth={5}
            color={subject.color}
          />
        </View>
      </View>

      <View style={styles.header}>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { backgroundColor: subject.color, width: `${progress}%` }]} />
          </View>
          <Text style={styles.progressText}>
            {currentQuestionIndex + 1} of {topicQuestions.length}
          </Text>
        </View>
        
        <TouchableOpacity style={styles.headerButton} onPress={handleRestart}>
          <RotateCcw size={20} color="#6b7280" />
        </TouchableOpacity>
      </View>

      <View style={styles.scoreContainer}>
        <View style={styles.scoreItem}>
          <Text style={[styles.scoreNumber, { color: subject.color }]}>
            {correctAnswers.length}
          </Text>
          <Text style={styles.scoreLabel}>Correct</Text>
        </View>
        
        <View style={styles.scoreItem}>
          <Text style={styles.scoreNumber}>{answeredQuestions.length - correctAnswers.length}</Text>
          <Text style={styles.scoreLabel}>Incorrect</Text>
        </View>
        
        <View style={styles.scoreItem}>
          <Text style={styles.scoreNumber}>
            {answeredQuestions.length > 0 
              ? Math.round((correctAnswers.length / answeredQuestions.length) * 100)
              : 0}%
          </Text>
          <Text style={styles.scoreLabel}>Accuracy</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <QuestionCard
          question={currentQuestion}
          onAnswer={handleAnswer}
          showResult={true}
        />
      </ScrollView>

      <View style={styles.navigation}>
        <TouchableOpacity
          style={[styles.navButton, currentQuestionIndex === 0 && styles.navButtonDisabled]}
          onPress={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
          disabled={currentQuestionIndex === 0}
        >
          <ArrowLeft size={20} color={currentQuestionIndex === 0 ? '#9ca3af' : subject.color} />
          <Text style={[
            styles.navButtonText,
            { color: subject.color },
            currentQuestionIndex === 0 && styles.navButtonTextDisabled
          ]}>
            Previous
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.navButton,
            currentQuestionIndex === topicQuestions.length - 1 && { backgroundColor: subject.color }
          ]}
          onPress={() => {
            if (currentQuestionIndex < topicQuestions.length - 1) {
              setCurrentQuestionIndex(currentQuestionIndex + 1);
            } else {
              handleSessionComplete();
            }
          }}
        >
          <Text style={[
            styles.navButtonText,
            { color: subject.color },
            currentQuestionIndex === topicQuestions.length - 1 && { color: '#ffffff' }
          ]}>
            {currentQuestionIndex === topicQuestions.length - 1 ? 'Finish' : 'Next'}
          </Text>
          {currentQuestionIndex === topicQuestions.length - 1 ? (
            <CheckCircle size={20} color="#ffffff" />
          ) : (
            <ArrowLeft 
              size={20} 
              color={subject.color}
              style={{ transform: [{ rotate: '180deg' }] }}
            />
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
  },
  errorText: {
    fontSize: 16,
    color: '#6b7280',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  topicHeader: {
    padding: 20,
  },
  topicInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  topicIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  topicDetails: {
    flex: 1,
    marginRight: 16,
  },
  topicName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 2,
  },
  subjectName: {
    fontSize: 14,
    color: '#6b7280',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  progressContainer: {
    flex: 1,
    marginRight: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#e5e7eb',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
  },
  progressText: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '600',
  },
  headerButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f3f4f6',
  },
  scoreContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginTop: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  scoreItem: {
    flex: 1,
    alignItems: 'center',
  },
  scoreNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
  },
  scoreLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  navigation: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    padding: 20,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  navButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f3f4f6',
    gap: 8,
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  navButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  navButtonTextDisabled: {
    color: '#9ca3af',
  },
});