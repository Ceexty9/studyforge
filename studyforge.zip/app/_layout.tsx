import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { StudyProvider } from "@/hooks/use-study-store";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerBackTitle: "Back" }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen 
        name="subject/[id]" 
        options={{ 
          headerShown: true,
          headerTitle: "Subject Details",
          presentation: "card",
        }} 
      />
      <Stack.Screen 
        name="practice/[id]" 
        options={{ 
          headerShown: true,
          headerTitle: "Practice Session",
          presentation: "card",
        }} 
      />
      <Stack.Screen 
        name="topic/[id]" 
        options={{ 
          headerShown: true,
          headerTitle: "Topic Practice",
          presentation: "card",
        }} 
      />
    </Stack>
  );
}

export default function RootLayout() {
  useEffect(() => {
    SplashScreen.hideAsync();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <StudyProvider>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <RootLayoutNav />
        </GestureHandlerRootView>
      </StudyProvider>
    </QueryClientProvider>
  );
}