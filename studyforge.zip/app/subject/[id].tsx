import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Play, Brain, BookOpen, Target } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';
import ProgressRing from '@/components/ProgressRing';

export default function SubjectDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { subjects, getSubjectProgress, getTopicQuestions } = useStudy();

  const subject = subjects.find(s => s.id === id);
  
  if (!subject) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Subject not found</Text>
      </View>
    );
  }

  const progress = getSubjectProgress(subject.id);

  const handleTopicPractice = (topicId: string) => {
    router.push(`/topic/${topicId}`);
  };

  const handleSubjectPractice = () => {
    router.push(`/practice/${subject.id}`);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={[styles.header, { backgroundColor: subject.color + '10' }]}>
        <View style={styles.headerContent}>
          <View style={[styles.subjectIcon, { backgroundColor: subject.color + '20' }]}>
            <BookOpen size={32} color={subject.color} />
          </View>
          
          <View style={styles.headerInfo}>
            <Text style={styles.subjectName}>{subject.name}</Text>
            <Text style={styles.subjectDescription}>{subject.description}</Text>
          </View>
          
          <ProgressRing
            progress={progress.progress}
            size={80}
            strokeWidth={6}
            color={subject.color}
          />
        </View>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{progress.totalQuestions}</Text>
          <Text style={styles.statLabel}>Total Questions</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={[styles.statNumber, { color: subject.color }]}>
            {progress.correctAnswers}
          </Text>
          <Text style={styles.statLabel}>Correct</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{progress.answeredQuestions}</Text>
          <Text style={styles.statLabel}>Answered</Text>
        </View>
      </View>

      <View style={styles.actionButtons}>
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: subject.color }]}
          onPress={handleSubjectPractice}
        >
          <Brain size={20} color="#ffffff" />
          <Text style={styles.actionButtonText}>Practice All</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.actionButton, styles.secondaryButton]}
          onPress={() => {/* TODO: Implement video navigation */}}
        >
          <Play size={20} color={subject.color} />
          <Text style={[styles.actionButtonText, { color: subject.color }]}>
            Watch Videos
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.topicsSection}>
        <Text style={styles.sectionTitle}>Topics</Text>
        
        {subject.topics.map((topic) => {
          const topicQuestions = getTopicQuestions(topic.id);
          const answeredQuestions = topicQuestions.filter(q => q.answered);
          const correctAnswers = topicQuestions.filter(q => q.correct);
          const topicProgress = topicQuestions.length > 0 
            ? (answeredQuestions.length / topicQuestions.length) * 100 
            : 0;

          return (
            <TouchableOpacity
              key={topic.id}
              style={styles.topicCard}
              onPress={() => handleTopicPractice(topic.id)}
            >
              <View style={styles.topicHeader}>
                <View style={[styles.topicIcon, { backgroundColor: subject.color + '20' }]}>
                  <Target size={20} color={subject.color} />
                </View>
                
                <View style={styles.topicInfo}>
                  <Text style={styles.topicName}>{topic.name}</Text>
                  <Text style={styles.topicDescription}>{topic.description}</Text>
                </View>
                
                <ProgressRing
                  progress={topicProgress}
                  size={50}
                  strokeWidth={4}
                  color={subject.color}
                  showPercentage={false}
                />
              </View>
              
              <View style={styles.topicStats}>
                <View style={styles.topicStat}>
                  <Text style={styles.topicStatNumber}>{topicQuestions.length}</Text>
                  <Text style={styles.topicStatLabel}>Questions</Text>
                </View>
                
                <View style={styles.topicStat}>
                  <Text style={[styles.topicStatNumber, { color: subject.color }]}>
                    {correctAnswers.length}
                  </Text>
                  <Text style={styles.topicStatLabel}>Correct</Text>
                </View>
                
                <View style={styles.topicStat}>
                  <Text style={styles.topicStatNumber}>
                    {Math.round(topicProgress)}%
                  </Text>
                  <Text style={styles.topicStatLabel}>Complete</Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
  },
  errorText: {
    fontSize: 16,
    color: '#6b7280',
  },
  header: {
    padding: 20,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subjectIcon: {
    width: 64,
    height: 64,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  headerInfo: {
    flex: 1,
    marginRight: 16,
  },
  subjectName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subjectDescription: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginTop: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginTop: 20,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  secondaryButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#e5e7eb',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  topicsSection: {
    padding: 20,
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  topicCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  topicHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  topicIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  topicInfo: {
    flex: 1,
    marginRight: 12,
  },
  topicName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  topicDescription: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 18,
  },
  topicStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  topicStat: {
    alignItems: 'center',
  },
  topicStatNumber: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  topicStatLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 2,
  },
});