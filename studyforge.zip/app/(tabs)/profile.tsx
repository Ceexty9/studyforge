import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { User, Trophy, Target, Flame, Clock, RotateCcw, Edit3 } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';
import ProgressRing from '@/components/ProgressRing';

export default function ProfileScreen() {
  const { user, updateUsername, resetProgress } = useStudy();
  const [isEditingUsername, setIsEditingUsername] = useState(false);
  const [newUsername, setNewUsername] = useState(user.username);

  const handleSaveUsername = async () => {
    if (newUsername.trim()) {
      await updateUsername(newUsername.trim());
      setIsEditingUsername(false);
    }
  };

  const handleResetProgress = () => {
    Alert.alert(
      'Reset Progress',
      'Are you sure you want to reset all your progress? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            await resetProgress();
            Alert.alert('Success', 'Your progress has been reset.');
          },
        },
      ]
    );
  };

  const accuracy = user.totalQuestionsAnswered > 0 
    ? (user.correctAnswers / user.totalQuestionsAnswered) * 100 
    : 0;

  const studyTimeHours = Math.floor(user.totalStudyTime / (1000 * 60 * 60));
  const studyTimeMinutes = Math.floor((user.totalStudyTime % (1000 * 60 * 60)) / (1000 * 60));

  const unlockedAchievements = user.achievements.filter(a => a.unlockedAt);
  const totalAchievements = user.achievements.length;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            <User size={40} color="#ffffff" />
          </View>
          
          <View style={styles.userInfo}>
            {isEditingUsername ? (
              <View style={styles.editContainer}>
                <TextInput
                  style={styles.usernameInput}
                  value={newUsername}
                  onChangeText={setNewUsername}
                  placeholder="Enter your username"
                  autoFocus
                  onSubmitEditing={handleSaveUsername}
                />
                <TouchableOpacity style={styles.saveButton} onPress={handleSaveUsername}>
                  <Text style={styles.saveButtonText}>Save</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.usernameContainer}>
                <Text style={styles.username}>
                  {user.username || 'Set your username'}
                </Text>
                <TouchableOpacity
                  style={styles.editButton}
                  onPress={() => setIsEditingUsername(true)}
                >
                  <Edit3 size={16} color="#6b7280" />
                </TouchableOpacity>
              </View>
            )}
            
            <Text style={styles.joinDate}>
              Joined {new Date(user.createdAt).toLocaleDateString()}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <ProgressRing
            progress={accuracy}
            size={60}
            strokeWidth={6}
            color="#10b981"
            showPercentage={false}
          />
          <Text style={styles.statNumber}>{Math.round(accuracy)}%</Text>
          <Text style={styles.statLabel}>Accuracy</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIcon}>
            <Target size={24} color="#3b82f6" />
          </View>
          <Text style={styles.statNumber}>{user.correctAnswers}</Text>
          <Text style={styles.statLabel}>Correct Answers</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIcon}>
            <Flame size={24} color="#f59e0b" />
          </View>
          <Text style={styles.statNumber}>{user.currentStreak}</Text>
          <Text style={styles.statLabel}>Day Streak</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIcon}>
            <Clock size={24} color="#8b5cf6" />
          </View>
          <Text style={styles.statNumber}>
            {studyTimeHours > 0 ? `${studyTimeHours}h` : `${studyTimeMinutes}m`}
          </Text>
          <Text style={styles.statLabel}>Study Time</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Achievements</Text>
        <Text style={styles.achievementProgress}>
          {unlockedAchievements.length} of {totalAchievements} unlocked
        </Text>
        
        <View style={styles.achievementsGrid}>
          {user.achievements.map((achievement) => (
            <View
              key={achievement.id}
              style={[
                styles.achievementCard,
                achievement.unlockedAt && styles.achievementUnlocked,
              ]}
            >
              <View style={[
                styles.achievementIcon,
                achievement.unlockedAt && styles.achievementIconUnlocked,
              ]}>
                <Trophy size={20} color={achievement.unlockedAt ? '#f59e0b' : '#9ca3af'} />
              </View>
              
              <Text style={[
                styles.achievementTitle,
                achievement.unlockedAt && styles.achievementTitleUnlocked,
              ]}>
                {achievement.title}
              </Text>
              
              <Text style={styles.achievementDescription}>
                {achievement.description}
              </Text>
              
              <View style={styles.achievementProgress}>
                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      { width: `${(achievement.progress / achievement.target) * 100}%` },
                    ]}
                  />
                </View>
                <Text style={styles.progressText}>
                  {achievement.progress}/{achievement.target}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Study Statistics</Text>
        
        <View style={styles.statRow}>
          <Text style={styles.statRowLabel}>Total Questions Answered</Text>
          <Text style={styles.statRowValue}>{user.totalQuestionsAnswered}</Text>
        </View>
        
        <View style={styles.statRow}>
          <Text style={styles.statRowLabel}>Correct Answers</Text>
          <Text style={styles.statRowValue}>{user.correctAnswers}</Text>
        </View>
        
        <View style={styles.statRow}>
          <Text style={styles.statRowLabel}>Current Streak</Text>
          <Text style={styles.statRowValue}>{user.currentStreak} days</Text>
        </View>
        
        <View style={styles.statRow}>
          <Text style={styles.statRowLabel}>Longest Streak</Text>
          <Text style={styles.statRowValue}>{user.longestStreak} days</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Settings</Text>
        
        <TouchableOpacity style={styles.settingItem} onPress={handleResetProgress}>
          <View style={styles.settingIcon}>
            <RotateCcw size={20} color="#ef4444" />
          </View>
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>Reset Progress</Text>
            <Text style={styles.settingDescription}>Clear all your study progress</Text>
          </View>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    backgroundColor: '#3b82f6',
    paddingTop: 20,
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  userInfo: {
    flex: 1,
  },
  editContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  usernameInput: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  usernameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  username: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffffff',
  },
  editButton: {
    padding: 4,
  },
  joinDate: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  achievementProgress: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 16,
  },
  achievementsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  achievementCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    opacity: 0.6,
  },
  achievementUnlocked: {
    opacity: 1,
    borderWidth: 2,
    borderColor: '#f59e0b',
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  achievementIconUnlocked: {
    backgroundColor: '#fef3c7',
  },
  achievementTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 4,
  },
  achievementTitleUnlocked: {
    color: '#111827',
  },
  achievementDescription: {
    fontSize: 10,
    color: '#9ca3af',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 14,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: '#e5e7eb',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#f59e0b',
  },
  progressText: {
    fontSize: 10,
    color: '#6b7280',
    marginLeft: 8,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  statRowLabel: {
    fontSize: 14,
    color: '#6b7280',
  },
  statRowValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fef2f2',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: '#6b7280',
  },
});