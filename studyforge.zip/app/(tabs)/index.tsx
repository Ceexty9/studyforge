import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Target, Trophy, Flame, Play, Brain } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';
import SubjectCard from '@/components/SubjectCard';
import ProgressRing from '@/components/ProgressRing';

export default function HomeScreen() {
  const router = useRouter();
  const { user, subjects, isLoading, getSubjectProgress } = useStudy();

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading your study data...</Text>
      </View>
    );
  }

  const totalQuestions = user.totalQuestionsAnswered;
  const accuracy = totalQuestions > 0 ? (user.correctAnswers / totalQuestions) * 100 : 0;

  const recentAchievements = user.achievements
    .filter(a => a.unlockedAt)
    .sort((a, b) => new Date(b.unlockedAt!).getTime() - new Date(a.unlockedAt!).getTime())
    .slice(0, 3);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.greeting}>
          {user.username ? `Welcome back, ${user.username}!` : 'Welcome to StudyApp!'}
        </Text>
        <Text style={styles.subtitle}>Continue your learning journey</Text>
      </View>

      {!user.username && (
        <TouchableOpacity
          style={styles.setupCard}
          onPress={() => router.push('/profile')}
        >
          <View style={styles.setupContent}>
            <Text style={styles.setupTitle}>Complete Your Profile</Text>
            <Text style={styles.setupDescription}>Set up your username to get started</Text>
          </View>
          <Text style={styles.setupArrow}>→</Text>
        </TouchableOpacity>
      )}

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <ProgressRing
            progress={accuracy}
            size={60}
            strokeWidth={6}
            color="#10b981"
            showPercentage={false}
          />
          <Text style={styles.statNumber}>{Math.round(accuracy)}%</Text>
          <Text style={styles.statLabel}>Accuracy</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIcon}>
            <Target size={24} color="#3b82f6" />
          </View>
          <Text style={styles.statNumber}>{user.correctAnswers}</Text>
          <Text style={styles.statLabel}>Correct</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIcon}>
            <Flame size={24} color="#f59e0b" />
          </View>
          <Text style={styles.statNumber}>{user.currentStreak}</Text>
          <Text style={styles.statLabel}>Day Streak</Text>
        </View>
      </View>

      <View style={styles.quickActions}>
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: '#3b82f6' }]}
          onPress={() => router.push('/practice')}
        >
          <Brain size={20} color="#ffffff" />
          <Text style={styles.actionButtonText}>Quick Practice</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: '#10b981' }]}
          onPress={() => router.push('/videos')}
        >
          <Play size={20} color="#ffffff" />
          <Text style={styles.actionButtonText}>Watch Videos</Text>
        </TouchableOpacity>
      </View>

      {recentAchievements.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Achievements</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.achievementsScroll}>
            {recentAchievements.map((achievement) => (
              <View key={achievement.id} style={styles.achievementCard}>
                <View style={styles.achievementIcon}>
                  <Trophy size={20} color="#f59e0b" />
                </View>
                <Text style={styles.achievementTitle}>{achievement.title}</Text>
                <Text style={styles.achievementDescription}>{achievement.description}</Text>
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Your Subjects</Text>
          <TouchableOpacity onPress={() => router.push('/subjects')}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        {subjects.map((subject) => {
          const progress = getSubjectProgress(subject.id);
          return (
            <SubjectCard
              key={subject.id}
              subject={subject}
              progress={progress.progress}
              totalQuestions={progress.totalQuestions}
              correctAnswers={progress.correctAnswers}
            />
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
  },
  loadingText: {
    fontSize: 16,
    color: '#6b7280',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  setupCard: {
    backgroundColor: '#dbeafe',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#3b82f6',
  },
  setupContent: {
    flex: 1,
  },
  setupTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e40af',
    marginBottom: 4,
  },
  setupDescription: {
    fontSize: 14,
    color: '#3730a3',
  },
  setupArrow: {
    fontSize: 20,
    color: '#3b82f6',
    fontWeight: '600',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  seeAllText: {
    fontSize: 14,
    color: '#3b82f6',
    fontWeight: '600',
  },
  achievementsScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  achievementCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginRight: 12,
    width: 140,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  achievementTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#111827',
    textAlign: 'center',
    marginBottom: 4,
  },
  achievementDescription: {
    fontSize: 10,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 14,
  },
});