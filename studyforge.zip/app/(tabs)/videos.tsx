import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Play, Download, CheckCircle, Clock, Wifi, WifiOff } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';

interface MockVideo {
  id: string;
  title: string;
  subject: string;
  duration: string;
  thumbnail: string;
  downloadStatus: 'not_downloaded' | 'downloading' | 'downloaded';
  downloadProgress: number;
}

const MOCK_VIDEOS: MockVideo[] = [
  {
    id: '1',
    title: 'Introduction to Algebra',
    subject: 'Mathematics',
    duration: '12:34',
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=225&fit=crop',
    downloadStatus: 'not_downloaded',
    downloadProgress: 0,
  },
  {
    id: '2',
    title: 'Linear Equations Explained',
    subject: 'Mathematics',
    duration: '18:45',
    thumbnail: 'https://images.unsplash.com/photo-1596495578065-6e0763fa1178?w=400&h=225&fit=crop',
    downloadStatus: 'downloaded',
    downloadProgress: 100,
  },
  {
    id: '3',
    title: 'Understanding Forces and Motion',
    subject: 'Physical Sciences',
    duration: '15:22',
    thumbnail: 'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=400&h=225&fit=crop',
    downloadStatus: 'downloading',
    downloadProgress: 65,
  },
  {
    id: '4',
    title: 'Cell Structure and Function',
    subject: 'Life Sciences',
    duration: '20:15',
    thumbnail: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=225&fit=crop',
    downloadStatus: 'not_downloaded',
    downloadProgress: 0,
  },
  {
    id: '5',
    title: 'Climate and Weather Patterns',
    subject: 'Geography',
    duration: '16:30',
    thumbnail: 'https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?w=400&h=225&fit=crop',
    downloadStatus: 'not_downloaded',
    downloadProgress: 0,
  },
];

export default function VideosScreen() {
  const { subjects } = useStudy();
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [videos, setVideos] = useState<MockVideo[]>(MOCK_VIDEOS);
  const [isOnline, setIsOnline] = useState(true);

  const filteredVideos = selectedSubject === 'all' 
    ? videos 
    : videos.filter(video => video.subject === subjects.find(s => s.id === selectedSubject)?.name);

  const downloadedVideos = videos.filter(v => v.downloadStatus === 'downloaded').length;
  const totalVideos = videos.length;

  const handleDownload = (videoId: string) => {
    if (!isOnline) {
      Alert.alert('No Internet Connection', 'Please connect to the internet to download videos.');
      return;
    }

    setVideos(prev => prev.map(video => {
      if (video.id === videoId) {
        if (video.downloadStatus === 'not_downloaded') {
          // Start download
          return { ...video, downloadStatus: 'downloading', downloadProgress: 0 };
        } else if (video.downloadStatus === 'downloaded') {
          // Remove download
          Alert.alert(
            'Remove Download',
            'Are you sure you want to remove this downloaded video?',
            [
              { text: 'Cancel', style: 'cancel' },
              { 
                text: 'Remove', 
                style: 'destructive',
                onPress: () => {
                  setVideos(prev => prev.map(v => 
                    v.id === videoId 
                      ? { ...v, downloadStatus: 'not_downloaded', downloadProgress: 0 }
                      : v
                  ));
                }
              },
            ]
          );
        }
      }
      return video;
    }));

    // Simulate download progress
    if (videos.find(v => v.id === videoId)?.downloadStatus === 'not_downloaded') {
      const interval = setInterval(() => {
        setVideos(prev => prev.map(video => {
          if (video.id === videoId && video.downloadStatus === 'downloading') {
            const newProgress = Math.min(video.downloadProgress + 10, 100);
            return {
              ...video,
              downloadProgress: newProgress,
              downloadStatus: newProgress === 100 ? 'downloaded' : 'downloading',
            };
          }
          return video;
        }));
      }, 500);

      setTimeout(() => clearInterval(interval), 5000);
    }
  };

  const handlePlayVideo = (video: MockVideo) => {
    if (video.downloadStatus === 'downloaded' || isOnline) {
      Alert.alert('Playing Video', `Now playing: ${video.title}`);
    } else {
      Alert.alert('Video Not Available', 'This video is not downloaded and you\'re offline.');
    }
  };

  const getDownloadIcon = (video: MockVideo) => {
    switch (video.downloadStatus) {
      case 'downloaded':
        return <CheckCircle size={20} color="#10b981" />;
      case 'downloading':
        return <Clock size={20} color="#f59e0b" />;
      default:
        return <Download size={20} color="#6b7280" />;
    }
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>Video Library</Text>
        <Text style={styles.subtitle}>Learn with high-quality educational videos</Text>
      </View>

      <View style={styles.statusBar}>
        <View style={styles.connectionStatus}>
          {isOnline ? (
            <Wifi size={16} color="#10b981" />
          ) : (
            <WifiOff size={16} color="#ef4444" />
          )}
          <Text style={[styles.statusText, { color: isOnline ? '#10b981' : '#ef4444' }]}>
            {isOnline ? 'Online' : 'Offline'}
          </Text>
        </View>
        
        <TouchableOpacity onPress={() => setIsOnline(!isOnline)}>
          <Text style={styles.toggleText}>Toggle Connection</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.downloadStats}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{downloadedVideos}</Text>
          <Text style={styles.statLabel}>Downloaded</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{totalVideos}</Text>
          <Text style={styles.statLabel}>Total Videos</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{Math.round((downloadedVideos / totalVideos) * 100)}%</Text>
          <Text style={styles.statLabel}>Offline Ready</Text>
        </View>
      </View>

      <View style={styles.filterSection}>
        <Text style={styles.sectionTitle}>Filter by Subject</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedSubject === 'all' && styles.filterButtonActive,
            ]}
            onPress={() => setSelectedSubject('all')}
          >
            <Text
              style={[
                styles.filterButtonText,
                selectedSubject === 'all' && styles.filterButtonTextActive,
              ]}
            >
              All Subjects
            </Text>
          </TouchableOpacity>
          
          {subjects.map((subject) => (
            <TouchableOpacity
              key={subject.id}
              style={[
                styles.filterButton,
                selectedSubject === subject.id && styles.filterButtonActive,
              ]}
              onPress={() => setSelectedSubject(subject.id)}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  selectedSubject === subject.id && styles.filterButtonTextActive,
                ]}
              >
                {subject.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <View style={styles.videosSection}>
        {filteredVideos.map((video) => (
          <View key={video.id} style={styles.videoCard}>
            <View style={styles.thumbnail}>
              <View style={styles.thumbnailOverlay}>
                <TouchableOpacity
                  style={styles.playButton}
                  onPress={() => handlePlayVideo(video)}
                >
                  <Play size={24} color="#ffffff" />
                </TouchableOpacity>
              </View>
              <Text style={styles.duration}>{video.duration}</Text>
            </View>
            
            <View style={styles.videoInfo}>
              <View style={styles.videoHeader}>
                <Text style={styles.videoTitle}>{video.title}</Text>
                <TouchableOpacity
                  style={styles.downloadButton}
                  onPress={() => handleDownload(video.id)}
                >
                  {getDownloadIcon(video)}
                </TouchableOpacity>
              </View>
              
              <Text style={styles.videoSubject}>{video.subject}</Text>
              
              {video.downloadStatus === 'downloading' && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        { width: `${video.downloadProgress}%` },
                      ]}
                    />
                  </View>
                  <Text style={styles.progressText}>{video.downloadProgress}%</Text>
                </View>
              )}
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  statusBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    borderRadius: 12,
    marginBottom: 16,
  },
  connectionStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  toggleText: {
    fontSize: 14,
    color: '#3b82f6',
    fontWeight: '600',
  },
  downloadStats: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 12,
  },
  statItem: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  filterSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  filterScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    backgroundColor: '#ffffff',
    marginRight: 12,
  },
  filterButtonActive: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  filterButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
  },
  filterButtonTextActive: {
    color: '#ffffff',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  videosSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  videoCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  thumbnail: {
    height: 200,
    backgroundColor: '#e5e7eb',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  thumbnailOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(59, 130, 246, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  duration: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    color: '#ffffff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontSize: 12,
    fontWeight: '600',
  },
  videoInfo: {
    padding: 16,
  },
  videoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  videoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    flex: 1,
    marginRight: 12,
  },
  downloadButton: {
    padding: 4,
  },
  videoSubject: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 8,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: '#e5e7eb',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#f59e0b',
  },
  progressText: {
    fontSize: 12,
    color: '#6b7280',
    fontWeight: '600',
  },
});