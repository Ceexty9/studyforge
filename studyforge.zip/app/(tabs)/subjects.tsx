import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useStudy } from '@/hooks/use-study-store';
import SubjectCard from '@/components/SubjectCard';

export default function SubjectsScreen() {
  const { subjects, getSubjectProgress } = useStudy();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>All Subjects</Text>
        <Text style={styles.subtitle}>Choose a subject to start learning</Text>
      </View>

      <View style={styles.content}>
        {subjects.map((subject) => {
          const progress = getSubjectProgress(subject.id);
          return (
            <SubjectCard
              key={subject.id}
              subject={subject}
              progress={progress.progress}
              totalQuestions={progress.totalQuestions}
              correctAnswers={progress.correctAnswers}
            />
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
});