import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Brain, Target, Clock, Trophy } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useStudy } from '@/hooks/use-study-store';

export default function PracticeScreen() {
  const router = useRouter();
  const { subjects, getSubjectProgress } = useStudy();
  const [selectedDifficulty, setSelectedDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');

  const difficulties = [
    { key: 'all', label: 'All Levels', color: '#6b7280' },
    { key: 'easy', label: 'Easy', color: '#10b981' },
    { key: 'medium', label: 'Medium', color: '#f59e0b' },
    { key: 'hard', label: 'Hard', color: '#ef4444' },
  ] as const;

  const handleSubjectPractice = (subjectId: string) => {
    router.push(`/practice/${subjectId}?difficulty=${selectedDifficulty}`);
  };

  const handleQuickPractice = () => {
    router.push(`/practice/mixed?difficulty=${selectedDifficulty}`);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>Practice Questions</Text>
        <Text style={styles.subtitle}>Test your knowledge and improve your skills</Text>
      </View>

      <View style={styles.difficultySelector}>
        <Text style={styles.sectionTitle}>Difficulty Level</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.difficultyScroll}>
          {difficulties.map((difficulty) => (
            <TouchableOpacity
              key={difficulty.key}
              style={[
                styles.difficultyButton,
                selectedDifficulty === difficulty.key && {
                  backgroundColor: difficulty.color,
                  borderColor: difficulty.color,
                },
              ]}
              onPress={() => setSelectedDifficulty(difficulty.key)}
            >
              <Text
                style={[
                  styles.difficultyButtonText,
                  selectedDifficulty === difficulty.key && styles.difficultyButtonTextActive,
                ]}
              >
                {difficulty.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <View style={styles.quickPracticeSection}>
        <TouchableOpacity style={styles.quickPracticeCard} onPress={handleQuickPractice}>
          <View style={styles.quickPracticeIcon}>
            <Brain size={32} color="#ffffff" />
          </View>
          <View style={styles.quickPracticeContent}>
            <Text style={styles.quickPracticeTitle}>Mixed Practice</Text>
            <Text style={styles.quickPracticeDescription}>
              Random questions from all subjects
            </Text>
          </View>
          <Text style={styles.quickPracticeArrow}>→</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Practice by Subject</Text>
        
        {subjects.map((subject) => {
          const progress = getSubjectProgress(subject.id);
          return (
            <TouchableOpacity
              key={subject.id}
              style={styles.subjectCard}
              onPress={() => handleSubjectPractice(subject.id)}
            >
              <View style={[styles.subjectIcon, { backgroundColor: subject.color + '20' }]}>
                <Target size={24} color={subject.color} />
              </View>
              
              <View style={styles.subjectContent}>
                <Text style={styles.subjectName}>{subject.name}</Text>
                <Text style={styles.subjectStats}>
                  {progress.totalQuestions} questions • {progress.correctAnswers} correct
                </Text>
              </View>
              
              <View style={styles.subjectProgress}>
                <Text style={[styles.progressText, { color: subject.color }]}>
                  {Math.round(progress.progress)}%
                </Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Practice Modes</Text>
        
        <TouchableOpacity style={styles.modeCard}>
          <View style={styles.modeIcon}>
            <Clock size={24} color="#3b82f6" />
          </View>
          <View style={styles.modeContent}>
            <Text style={styles.modeTitle}>Timed Practice</Text>
            <Text style={styles.modeDescription}>Challenge yourself with time limits</Text>
          </View>
          <Text style={styles.comingSoonBadge}>Coming Soon</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.modeCard}>
          <View style={styles.modeIcon}>
            <Trophy size={24} color="#f59e0b" />
          </View>
          <View style={styles.modeContent}>
            <Text style={styles.modeTitle}>Challenge Mode</Text>
            <Text style={styles.modeDescription}>Compete with your best scores</Text>
          </View>
          <Text style={styles.comingSoonBadge}>Coming Soon</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  difficultySelector: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  difficultyScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  difficultyButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    backgroundColor: '#ffffff',
    marginRight: 12,
  },
  difficultyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
  },
  difficultyButtonTextActive: {
    color: '#ffffff',
  },
  quickPracticeSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  quickPracticeCard: {
    backgroundColor: '#3b82f6',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  quickPracticeIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  quickPracticeContent: {
    flex: 1,
  },
  quickPracticeTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 4,
  },
  quickPracticeDescription: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  quickPracticeArrow: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: '600',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  subjectCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  subjectIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  subjectContent: {
    flex: 1,
  },
  subjectName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  subjectStats: {
    fontSize: 14,
    color: '#6b7280',
  },
  subjectProgress: {
    alignItems: 'center',
  },
  progressText: {
    fontSize: 16,
    fontWeight: '700',
  },
  modeCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    opacity: 0.6,
  },
  modeIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#f3f4f6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  modeContent: {
    flex: 1,
  },
  modeTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  modeDescription: {
    fontSize: 14,
    color: '#6b7280',
  },
  comingSoonBadge: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
  },
});