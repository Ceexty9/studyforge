import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, RotateCcw, CheckCircle } from 'lucide-react-native';
import { useStudy } from '@/hooks/use-study-store';
import QuestionCard from '@/components/QuestionCard';
import { Question } from '@/types/study';

export default function PracticeScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { subjects, questions, answerQuestion, startSession, endSession } = useStudy();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
  const [sessionStarted, setSessionStarted] = useState(false);

  useEffect(() => {
    if (id && !sessionStarted) {
      let practiceQuestions: Question[] = [];
      
      if (id === 'mixed') {
        // Mixed practice - random questions from all subjects
        practiceQuestions = [...questions].sort(() => Math.random() - 0.5).slice(0, 10);
      } else {
        // Subject-specific practice
        const subject = subjects.find(s => s.id === id);
        if (subject) {
          const subjectTopicIds = subject.topics.map(t => t.id);
          practiceQuestions = questions.filter(q => subjectTopicIds.includes(q.topicId));
        }
      }
      
      setSessionQuestions(practiceQuestions);
      if (practiceQuestions.length > 0) {
        startSession(id === 'mixed' ? 'mixed' : id, 'practice');
        setSessionStarted(true);
      }
    }
  }, [id, questions, subjects, startSession, sessionStarted]);

  const handleAnswer = async (questionId: string, answer: number) => {
    await answerQuestion(questionId, answer);
    
    // Move to next question after a delay
    setTimeout(() => {
      if (currentQuestionIndex < sessionQuestions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        // Session complete
        handleSessionComplete();
      }
    }, 2000);
  };

  const handleSessionComplete = async () => {
    await endSession();
    
    const answeredQuestions = sessionQuestions.filter(q => q.answered);
    const correctAnswers = answeredQuestions.filter(q => q.correct);
    const score = answeredQuestions.length > 0 
      ? Math.round((correctAnswers.length / answeredQuestions.length) * 100) 
      : 0;

    Alert.alert(
      'Practice Complete!',
      `You scored ${score}% (${correctAnswers.length}/${answeredQuestions.length} correct)`,
      [
        { text: 'Review Answers', onPress: () => setCurrentQuestionIndex(0) },
        { text: 'Back to Home', onPress: () => router.push('/') },
      ]
    );
  };

  const handleRestart = () => {
    Alert.alert(
      'Restart Practice',
      'Are you sure you want to restart this practice session?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Restart', 
          onPress: () => {
            setCurrentQuestionIndex(0);
            setSessionStarted(false);
          }
        },
      ]
    );
  };

  if (sessionQuestions.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No questions available for this practice session.</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const currentQuestion = sessionQuestions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / sessionQuestions.length) * 100;
  const answeredQuestions = sessionQuestions.filter(q => q.answered);
  const correctAnswers = answeredQuestions.filter(q => q.correct);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progress}%` }]} />
          </View>
          <Text style={styles.progressText}>
            {currentQuestionIndex + 1} of {sessionQuestions.length}
          </Text>
        </View>
        
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton} onPress={handleRestart}>
            <RotateCcw size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.scoreContainer}>
        <View style={styles.scoreItem}>
          <Text style={styles.scoreNumber}>{correctAnswers.length}</Text>
          <Text style={styles.scoreLabel}>Correct</Text>
        </View>
        
        <View style={styles.scoreItem}>
          <Text style={styles.scoreNumber}>{answeredQuestions.length - correctAnswers.length}</Text>
          <Text style={styles.scoreLabel}>Incorrect</Text>
        </View>
        
        <View style={styles.scoreItem}>
          <Text style={styles.scoreNumber}>
            {answeredQuestions.length > 0 
              ? Math.round((correctAnswers.length / answeredQuestions.length) * 100)
              : 0}%
          </Text>
          <Text style={styles.scoreLabel}>Accuracy</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <QuestionCard
          question={currentQuestion}
          onAnswer={handleAnswer}
          showResult={true}
        />
      </ScrollView>

      <View style={styles.navigation}>
        <TouchableOpacity
          style={[styles.navButton, currentQuestionIndex === 0 && styles.navButtonDisabled]}
          onPress={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
          disabled={currentQuestionIndex === 0}
        >
          <ArrowLeft size={20} color={currentQuestionIndex === 0 ? '#9ca3af' : '#3b82f6'} />
          <Text style={[
            styles.navButtonText,
            currentQuestionIndex === 0 && styles.navButtonTextDisabled
          ]}>
            Previous
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.navButton,
            currentQuestionIndex === sessionQuestions.length - 1 && styles.navButtonDisabled
          ]}
          onPress={() => {
            if (currentQuestionIndex < sessionQuestions.length - 1) {
              setCurrentQuestionIndex(currentQuestionIndex + 1);
            } else {
              handleSessionComplete();
            }
          }}
        >
          <Text style={[
            styles.navButtonText,
            currentQuestionIndex === sessionQuestions.length - 1 && styles.navButtonTextDisabled
          ]}>
            {currentQuestionIndex === sessionQuestions.length - 1 ? 'Finish' : 'Next'}
          </Text>
          {currentQuestionIndex === sessionQuestions.length - 1 ? (
            <CheckCircle size={20} color="#10b981" />
          ) : (
            <ArrowLeft 
              size={20} 
              color={currentQuestionIndex === sessionQuestions.length - 1 ? '#9ca3af' : '#3b82f6'}
              style={{ transform: [{ rotate: '180deg' }] }}
            />
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  progressContainer: {
    flex: 1,
    marginRight: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#e5e7eb',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#3b82f6',
  },
  progressText: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '600',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f3f4f6',
  },
  scoreContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginTop: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  scoreItem: {
    flex: 1,
    alignItems: 'center',
  },
  scoreNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
  },
  scoreLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  navigation: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    padding: 20,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  navButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f3f4f6',
    gap: 8,
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  navButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3b82f6',
  },
  navButtonTextDisabled: {
    color: '#9ca3af',
  },
});