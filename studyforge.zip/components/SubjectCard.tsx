import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Calculator, Atom, Leaf, Globe } from 'lucide-react-native';
import ProgressRing from './ProgressRing';
import { Subject } from '@/types/study';

interface SubjectCardProps {
  subject: Subject;
  progress: number;
  totalQuestions: number;
  correctAnswers: number;
}

const SUBJECT_ICONS = {
  calculator: Calculator,
  atom: Atom,
  leaf: Leaf,
  globe: Globe,
};

export default function SubjectCard({ subject, progress, totalQuestions, correctAnswers }: SubjectCardProps) {
  const router = useRouter();
  const IconComponent = SUBJECT_ICONS[subject.icon as keyof typeof SUBJECT_ICONS] || Calculator;

  const handlePress = () => {
    router.push(`/subject/${subject.id}`);
  };

  return (
    <TouchableOpacity style={styles.card} onPress={handlePress} testID={`subject-card-${subject.id}`}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: subject.color + '20' }]}>
          <IconComponent size={24} color={subject.color} />
        </View>
        <ProgressRing
          progress={progress}
          size={50}
          strokeWidth={4}
          color={subject.color}
          showPercentage={false}
        />
      </View>
      
      <Text style={styles.title}>{subject.name}</Text>
      <Text style={styles.description}>{subject.description}</Text>
      
      <View style={styles.stats}>
        <View style={styles.stat}>
          <Text style={styles.statNumber}>{totalQuestions}</Text>
          <Text style={styles.statLabel}>Questions</Text>
        </View>
        <View style={styles.stat}>
          <Text style={[styles.statNumber, { color: subject.color }]}>{correctAnswers}</Text>
          <Text style={styles.statLabel}>Correct</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statNumber}>{Math.round(progress)}%</Text>
          <Text style={styles.statLabel}>Complete</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 16,
    lineHeight: 20,
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 2,
  },
});