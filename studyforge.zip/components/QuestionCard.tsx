import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { CheckCircle, XCircle, HelpCircle } from 'lucide-react-native';
import { Question } from '@/types/study';

interface QuestionCardProps {
  question: Question;
  onAnswer: (questionId: string, answer: number) => void;
  showResult?: boolean;
}

export default function QuestionCard({ question, onAnswer, showResult = false }: QuestionCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(
    question.answered ? question.userAnswer || null : null
  );
  const [showExplanation, setShowExplanation] = useState(false);

  const handleAnswerSelect = (answerIndex: number) => {
    if (question.answered) return;
    
    setSelectedAnswer(answerIndex);
    onAnswer(question.id, answerIndex);
    
    setTimeout(() => {
      setShowExplanation(true);
    }, 500);
  };

  const getDifficultyColor = () => {
    switch (question.difficulty) {
      case 'easy': return '#10b981';
      case 'medium': return '#f59e0b';
      case 'hard': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getOptionStyle = (index: number) => {
    if (!question.answered && selectedAnswer === null) {
      return styles.option;
    }

    if (index === question.correctAnswer) {
      return [styles.option, styles.correctOption];
    }

    if (selectedAnswer === index && index !== question.correctAnswer) {
      return [styles.option, styles.incorrectOption];
    }

    return [styles.option, styles.disabledOption];
  };

  const getOptionIcon = (index: number) => {
    if (!question.answered) return null;

    if (index === question.correctAnswer) {
      return <CheckCircle size={20} color="#10b981" />;
    }

    if (selectedAnswer === index && index !== question.correctAnswer) {
      return <XCircle size={20} color="#ef4444" />;
    }

    return null;
  };

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor() }]}>
          <Text style={styles.difficultyText}>{question.difficulty.toUpperCase()}</Text>
        </View>
        {question.answered && (
          <TouchableOpacity
            style={styles.helpButton}
            onPress={() => setShowExplanation(!showExplanation)}
          >
            <HelpCircle size={20} color="#6b7280" />
          </TouchableOpacity>
        )}
      </View>

      <Text style={styles.questionText}>{question.question}</Text>

      <View style={styles.options}>
        {question.options.map((option, index) => (
          <TouchableOpacity
            key={index}
            style={getOptionStyle(index)}
            onPress={() => handleAnswerSelect(index)}
            disabled={question.answered}
            testID={`option-${index}`}
          >
            <View style={styles.optionContent}>
              <Text style={[
                styles.optionText,
                question.answered && index === question.correctAnswer && styles.correctText,
                question.answered && selectedAnswer === index && index !== question.correctAnswer && styles.incorrectText,
              ]}>
                {option}
              </Text>
              {getOptionIcon(index)}
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {showExplanation && question.answered && (
        <View style={styles.explanation}>
          <Text style={styles.explanationTitle}>Explanation:</Text>
          <Text style={styles.explanationText}>{question.explanation}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  difficultyText: {
    color: '#ffffff',
    fontSize: 10,
    fontWeight: '600',
  },
  helpButton: {
    padding: 4,
  },
  questionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 16,
    lineHeight: 24,
  },
  options: {
    gap: 12,
  },
  option: {
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 12,
    padding: 16,
    backgroundColor: '#ffffff',
  },
  correctOption: {
    borderColor: '#10b981',
    backgroundColor: '#ecfdf5',
  },
  incorrectOption: {
    borderColor: '#ef4444',
    backgroundColor: '#fef2f2',
  },
  disabledOption: {
    opacity: 0.6,
  },
  optionContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  optionText: {
    fontSize: 14,
    color: '#374151',
    flex: 1,
  },
  correctText: {
    color: '#059669',
    fontWeight: '600',
  },
  incorrectText: {
    color: '#dc2626',
    fontWeight: '600',
  },
  explanation: {
    marginTop: 16,
    padding: 16,
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#3b82f6',
  },
  explanationTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  explanationText: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
  },
});